# IMPORTING IMPORTANT LIBRARIES
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.layers import LSTM
from keras.wrappers.scikit_learn import KerasClassifier
import os
import csv
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import GridSearchCV
os.environ['KMP_DUPLICATE_LIB_OK']='True'

# FOR REPRODUCIBILITY
np.random.seed(7)

# IMPORTING DATASET
load_cascading = pd.read_csv('load_cascading_study2.csv', header=0, index_col= 0)

graph_features = pd.read_csv('dp_comb_data.csv', header=0, index_col= 0)

comb_dataset = pd.concat([load_cascading,  graph_features], axis= 1)


scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(comb_dataset.values)

def to_supervised(data,dropNa = True,lag = 1):
    df = pd.DataFrame(data)
    column = []
    column.append(df)
    for i in range(1,lag+1):
        column.append(df.shift(-i))
    df = pd.concat(column,axis=1)
    df.dropna(inplace = True)
    features = data.shape[1]
    df = df.values
    supervised_data = df[:,:features*lag]
    supervised_data = np.column_stack([supervised_data, df[:,features*lag]])
    return supervised_data

timeSteps = 1 # 2,3,4,...

supervised = to_supervised(scaled_data,lag=timeSteps)

features = scaled_data.shape[1]
X = supervised[:,:features*timeSteps]
y = supervised[:,features*timeSteps]
training_length = int(supervised.shape[0]*0.6)
x_train = X[:training_length,:]
x_test = X[training_length:,:]
y_train = y[:training_length]
y_test = y[training_length:]

#convert data to fit for lstm
x_train = x_train.reshape(x_train.shape[0], timeSteps, features)
x_test = x_test.reshape(x_test.shape[0], timeSteps, features)

# LSTM MODEL
def create_model(dropout_rate = 0.0):
    model = Sequential()
    model.add(LSTM(128, input_shape=(timeSteps, x_train.shape[2]), return_sequences=True))
    model.add(Dropout(dropout_rate))
    model.add(LSTM(64))
    model.add(Dropout(dropout_rate))
    model.add(Dense(1))
    model.add(Activation('relu'))

    # MODEL COMPILING AND TRAINING
    model.compile(loss='mean_squared_error', optimizer='Adagrad', metrics = ['accuracy'])  # Try SGD, adam, adagrad
    return  model


seed = 7
np.random.seed(seed)
model = KerasClassifier(build_fn=create_model, epochs = 500, batch_size = 5,verbose=2)
dropout_rate = [0.5,0.55,0.6,0.65,0.7]
param_grid = dict(dropout_rate = dropout_rate)
grid = GridSearchCV(estimator=model, param_grid=param_grid, n_jobs=-1)
grid_result = grid.fit(x_train, y_train)

print("Best: %f using %s" % (grid_result.best_score_, grid_result.best_params_))
means = grid_result.cv_results_['mean_test_score']
stds = grid_result.cv_results_['std_test_score']
params = grid_result.cv_results_['params']
for mean, stdev, param in zip(means, stds, params):
    print("%f (%f) with: %r" % (mean, stdev, param))