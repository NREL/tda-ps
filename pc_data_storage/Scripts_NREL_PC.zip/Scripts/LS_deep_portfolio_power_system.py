import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import copy

from keras.layers import Input, Dense
from keras.models import Model
from keras import regularizers
from keras.models import load_model
from sklearn.preprocessing import StandardScaler
from collections import defaultdict

# features/variables loading #
graph_features = pd.read_csv("dp_comb_data.csv", index_col= 0)
load_served = pd.read_csv("load_served_study2.csv", index_col= 0)

# autoencoder model #
encoding_dim = 5
num_graph_features = graph_features.shape[1]

input_img = Input(shape=(num_graph_features,))
encoded = Dense(encoding_dim, activation= 'relu', kernel_regularizer= regularizers.l2(0.01))(input_img)
decoded = Dense(num_graph_features, activation='linear', kernel_regularizer= regularizers.l2(0.01))(encoded)

autoencoder = Model(input_img, decoded)
autoencoder.compile(optimizer='sgd', loss= 'mean_squared_error')

# train autoencoder #
data = graph_features.iloc[0:60,:]
autoencoder.fit(data, data, shuffle= False, epochs= 500, batch_size= 10)
autoencoder.save('ls_retrack_autoencoder.h5')

reconstruct = autoencoder.predict(data)

# communnal information #
communal_information = []

for i in range(0, graph_features.shape[1]):
    diff = np.linalg.norm((data.iloc[:, i] - reconstruct[:, i]))  # 2 norm difference
    communal_information.append(float(diff))

print("graph feature #, 2-norm, graph feature name")
ranking = np.array(communal_information).argsort()
for graph_feature_index in ranking:
    print(graph_feature_index, communal_information[graph_feature_index], data.iloc[:, graph_feature_index].name)


# calibration #
load_served_predict = defaultdict(defaultdict)
total_2_norm_diff = defaultdict(defaultdict)
dl_scaler = defaultdict(StandardScaler)

for non_communal in [2,4,6,8,10,12,14,16,18,20]:
    # some numerical values
    encoding_dim = 5
    s = 5 + non_communal
    graph_feature_index = np.concatenate((ranking[0:5], ranking[-non_communal:]))  # portfolio index

    # connect all layers
    input_img = Input(shape=(s,))
    encoded = Dense(encoding_dim, activation='relu', kernel_regularizer=regularizers.l2(0.01))(input_img)
    decoded = Dense(1, activation='linear', kernel_regularizer=regularizers.l2(0.01))(encoded)

    # construct and compile deep learning routine
    deep_learner = Model(input_img, decoded)
    deep_learner.compile(optimizer='rmsprop', loss='mean_squared_error')

    x = data.iloc[:, graph_feature_index]
    y = load_served.iloc[0:60,]

    dl_scaler[s] = StandardScaler()  # Multi-layer Perceptron is sensitive to feature scaling, so it is highly recommended to scale your data
    dl_scaler[s].fit(x)
    x = dl_scaler[s].transform(x)

    deep_learner.fit(x, y, shuffle=False, epochs=500, batch_size=1)  # fit the model
    deep_learner.save('ls_retrack_s' + str(s) + '.h5')  # for validation phase use

    # is it good?
    load_served_prediction = copy.deepcopy(deep_learner.predict(x))

    load_served_predict['calibrate'][s] = load_served_prediction
    total_2_norm_diff['calibrate'][s] = np.linalg.norm((load_served_predict['calibrate'][s] - y))



pd.Series(load_served.iloc[0:60,0].values).plot(label='Load Served original', legend=True, lw = 3)

for s in [7,9,11,13,15,17,19,21,23,25]:
    pd.Series(load_served_predict['calibrate'][s][:,0]).plot(label="# Graph Features" + ":" + str(s), legend=True)
    print("# Graph Features" + ":" + str(s) + " 2-norm difference: ", total_2_norm_diff['calibrate'][s])
plt.show()

# Graph Features:7 2-norm difference:  20.489655166834726
# Graph Features:9 2-norm difference:  170.23012899030098
# Graph Features:11 2-norm difference:  110.70671673530538
# Graph Features:13 2-norm difference:  35.891632806492616
# Graph Features:15 2-norm difference:  49.809700259734576
# Graph Features:17 2-norm difference:  36.57631276303877
# Graph Features:19 2-norm difference:  27.45324389044901
# Graph Features:21 2-norm difference:  46.663342616073024
# Graph Features:23 2-norm difference:  26.561380896665437
# Graph Features:25 2-norm difference:  74.03797771130246


# verifying #
error = []
for non_communal in [2,4,6,8,10,12,14,16,18,20]:
    # some numerical values
    encoding_dim = 5
    s = 5 + non_communal
    graph_feature_index = np.concatenate((ranking[0:5], ranking[-non_communal:]))  # portfolio index

    # training
    input_img = Input(shape=(s,))
    encoded = Dense(encoding_dim, activation='relu', kernel_regularizer=regularizers.l2(0.01))(input_img)
    decoded = Dense(1, activation='linear', kernel_regularizer=regularizers.l2(0.01))(encoded)

    deep_learner = Model(input_img, decoded)
    deep_learner.compile(optimizer='rmsprop', loss='mean_squared_error')

    x_train = graph_features.iloc[0:60, graph_feature_index]
    y_train = load_served.iloc[0:60,:]

    dl_scaler[
        s] = StandardScaler()  # Multi-layer Perceptron is sensitive to feature scaling, so it is highly recommended to scale your data
    dl_scaler[s].fit(x_train)
    x_train = dl_scaler[s].transform(x_train)

    deep_learner.fit(x_train, y_train, shuffle=False, epochs=500, batch_size=1)  # fit the model

    # testing
    x_test = graph_features.iloc[60:101,graph_feature_index]
    y_test = load_served.iloc[60:101,:]

    x_test = dl_scaler[s].transform(x_test)

    load_served_test_prediction = copy.deepcopy(deep_learner.predict(x_test))

    error.append(np.linalg.norm((load_served_test_prediction - y_test)))
    load_served_predict['test'][s] = load_served_test_prediction


pd.Series(load_served.iloc[60:101,0].values).plot(label='Load Served original', legend=False, lw = 3)

for s in [7,9,11,13,15,17,19,21,23,25]:
    pd.Series(load_served_predict['test'][s][:,0]).plot(label="# Graph Features" + ":" + str(s), legend=False)

plt.grid(zorder=0)
plt.legend(loc='center left', bbox_to_anchor=(1.0, 0.5))
plt.show()



mse = [e/len(y_test) for e in error] # mse = sum of 2 norm difference/ # of test dates
print(mse)
plt.gca().invert_yaxis()
plt.plot(mse, [7,9,11,13,15,17,19,21,23,25])
plt.xlabel('Mean Squared Error')
plt.ylabel('number of stocks in the portfolio')
plt.show()
