import gudhi
import csv
import pandas as pd
import numpy as np
from sklearn.kernel_approximation import RBFSampler
from sklearn_tda import *
from gudhi import bottleneck_distance
from pathlib import Path

summary_kernel_distance_result2 = np.zeros((10,9),dtype=float)

# weight_matrix_ generate from tda_distance_matrix.R file #

for uu in range(10):
    weight_filename = "weight_matrix_" + str(uu) + ".csv"
    test_filename = Path(weight_filename)
    if test_filename.is_file():
        target_matrix = gudhi.read_lower_triangular_matrix_from_csv_file('weight_matrix_0.csv')
        rips_complex = gudhi.RipsComplex(distance_matrix=target_matrix, max_edge_length=1)
        simplex_tree = rips_complex.create_simplex_tree(max_dimension=1)
        diag = simplex_tree.persistence(homology_coeff_field=2, min_persistence=0)

        # transform the diag to X_arrays which shape is n*2 that is remove n*1 label column
        X_arrays = np.zeros((len(diag), 2), dtype=float)
        for i in range(len(diag)):
            X_arrays[i, :] = np.asarray(diag[i][1])

        for j in range(len(diag)):
            if X_arrays[j, 1] == float("Inf"):
                X_arrays[j, 1] = 1

        target_matrix_compared = gudhi.read_lower_triangular_matrix_from_csv_file(weight_filename)
        rips_complex_compared = gudhi.RipsComplex(distance_matrix=target_matrix_compared, max_edge_length=1)
        simplex_tree_compared = rips_complex_compared.create_simplex_tree(max_dimension=1)
        diag_compared = simplex_tree_compared.persistence(homology_coeff_field=2, min_persistence=0)

        X_arrays_compared = np.zeros((len(diag_compared), 2), dtype=float)
        for i in range(len(diag_compared)):
            X_arrays_compared[i, :] = np.asarray(diag_compared[i][1])

        for j in range(len(diag_compared)):
            if X_arrays_compared[j, 1] == float("Inf"):
                X_arrays_compared[j, 1] = 1

        X_arrays = [X_arrays]
        X_arrays_compared = [X_arrays_compared]


        def arctan(C, p):
            return lambda x: C * np.arctan(np.power(x[1], p))


        PWG = PersistenceWeightedGaussianKernel(bandwidth=1., kernel_approx=None, weight=arctan(1., 1.))
        X = PWG.fit(X_arrays)
        Y = PWG.transform(X_arrays_compared)
        summary_kernel_distance_result2[uu, 0] = Y[0][0]

        PWG = PersistenceWeightedGaussianKernel(
            kernel_approx=RBFSampler(gamma=1. / 2, n_components=100000).fit(np.ones([1, 2])), weight=arctan(1., 1.))
        X = PWG.fit(X_arrays)
        Y = PWG.transform(X_arrays_compared)
        summary_kernel_distance_result2[uu, 1] = Y[0][0]

        PSS = PersistenceScaleSpaceKernel(bandwidth=1.)
        X = PSS.fit(X_arrays)
        Y = PSS.transform(X_arrays_compared)
        summary_kernel_distance_result2[uu, 2] = Y[0][0]

        PSS = PersistenceScaleSpaceKernel(
            kernel_approx=RBFSampler(gamma=1. / 2, n_components=100000).fit(np.ones([1, 2])))
        X = PSS.fit(X_arrays)
        Y = PSS.transform(X_arrays_compared)
        summary_kernel_distance_result2[uu, 3] = Y[0][0]

        sW = SlicedWassersteinDistance(num_directions=100)
        X = sW.fit(X_arrays)
        Y = sW.transform(X_arrays_compared)
        summary_kernel_distance_result2[uu, 4] = Y[0][0]

        SW = SlicedWassersteinKernel(num_directions=100, bandwidth=10)
        X = SW.fit(X_arrays)
        Y = SW.transform(X_arrays_compared)
        summary_kernel_distance_result2[uu, 5] = Y[0][0]

        W = BottleneckDistance(epsilon=.001)
        X = W.fit(X_arrays)
        Y = W.transform(X_arrays_compared)
        summary_kernel_distance_result2[uu, 6] = Y[0][0]

        PF = PersistenceFisherKernel(bandwidth_fisher=1., bandwidth=1.)
        X = PF.fit(X_arrays)
        Y = PF.transform(X_arrays_compared)
        summary_kernel_distance_result2[uu, 7] = Y[0][0]

        PF = PersistenceFisherKernel(bandwidth_fisher=1., bandwidth=1.,
                                     kernel_approx=RBFSampler(gamma=1. / 2, n_components=100000).fit(np.ones([1, 2])))
        X = PF.fit(X_arrays)
        Y = PF.transform(X_arrays_compared)
        summary_kernel_distance_result2[uu, 8] = Y[0][0]
    else:
        summary_kernel_distance_result2[uu, 0] = 0
        summary_kernel_distance_result2[uu, 1] = 0
        summary_kernel_distance_result2[uu, 2] = 0
        summary_kernel_distance_result2[uu, 3] = 0
        summary_kernel_distance_result2[uu, 4] = 0
        summary_kernel_distance_result2[uu, 5] = 0
        summary_kernel_distance_result2[uu, 6] = 0
        summary_kernel_distance_result2[uu, 7] = 0
        summary_kernel_distance_result2[uu, 8] = 0





summary_kernel_distance_result2_df = pd.DataFrame(summary_kernel_distance_result2, columns=['PWG_kernel','Approximate_PWG_kernel',
                                                                                            'PSS_kernel','Approximate_PSS_kernel',
                                                                                            'SW_distance','SW_kernel','Bottleneck_distance',
                                                                                            'PF_kernel','Approximate_PF_kernel'])

path='/Users/yuzhouchen/Downloads/summary_kernel_distance_result_haha.csv'
summary_kernel_distance_result2_df.to_csv(path,index=True)

