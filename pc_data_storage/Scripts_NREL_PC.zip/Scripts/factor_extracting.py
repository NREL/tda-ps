import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import copy

from keras.layers import Input, Dense
from keras.models import Model
from keras import regularizers
from keras.models import load_model
from sklearn.preprocessing import StandardScaler
from collections import defaultdict

# features/variables loading #
graph_features = pd.read_csv("dp_comb_data.csv", index_col= 0)
load_cascading = pd.read_csv("load_cascading_study2.csv", index_col= 0)



# loop begin #
features_summary = np.empty(shape=(100,25), dtype='U25')
for ii in range(100):
    print(ii)
    # autoencoder model #
    encoding_dim = 5
    num_graph_features = graph_features.shape[1]

    input_img = Input(shape=(num_graph_features,))
    encoded = Dense(encoding_dim, activation='relu', kernel_regularizer=regularizers.l2(0.01))(input_img)
    decoded = Dense(num_graph_features, activation='linear', kernel_regularizer=regularizers.l2(0.01))(encoded)

    autoencoder = Model(input_img, decoded)
    autoencoder.compile(optimizer='sgd', loss='mean_squared_error')

    # train autoencoder #
    data = graph_features.iloc[0:60, :]
    autoencoder.fit(data, data, shuffle=False, epochs=500, batch_size=10)
    autoencoder.save('new_retrack_autoencoder.h5')

    reconstruct = autoencoder.predict(data)

    # communnal information #
    communal_information = []

    for i in range(0, graph_features.shape[1]):
        diff = np.linalg.norm((data.iloc[:, i] - reconstruct[:, i]))  # 2 norm difference
        communal_information.append(float(diff))

    # model over #
    ranking = np.array(communal_information).argsort()
    j = 0
    for graph_feature_index in ranking:
        features_summary[ii,j] = data.iloc[:, graph_feature_index].name
        j += 1

    features_summary_df = pd.DataFrame(features_summary)
    features_summary_df.to_csv("deep_portfolio_features_summary.csv")