#!/usr/bin/env Rscript

require(igraph)

print("Hello, Eagle!")
