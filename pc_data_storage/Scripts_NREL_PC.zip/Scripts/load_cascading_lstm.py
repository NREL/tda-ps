# IMPORTING IMPORTANT LIBRARIES
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.layers import LSTM
import os
import csv
from sklearn.preprocessing import LabelEncoder
from keras.layers.normalization import BatchNormalization
os.environ['KMP_DUPLICATE_LIB_OK']='True'

# FOR REPRODUCIBILITY
#np.random.seed(7)

# IMPORTING DATASET
load_cascading = pd.read_csv('load_cascading_study2.csv', header=0, index_col= 0)

graph_features = pd.read_csv('dp_comb_data_after_deep_portfolio.csv', header=0, index_col= 0) #dp_comb_data

comb_dataset = pd.concat([load_cascading,  graph_features], axis= 1)


scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(comb_dataset.values)

def to_supervised(data,dropNa = True,lag = 1):
    df = pd.DataFrame(data)
    column = []
    column.append(df)
    for i in range(1,lag+1):
        column.append(df.shift(-i))
    df = pd.concat(column,axis=1)
    df.dropna(inplace = True)
    features = data.shape[1]
    df = df.values
    supervised_data = df[:,:features*lag]
    supervised_data = np.column_stack([supervised_data, df[:,features*lag]])
    return supervised_data

timeSteps = 1 # 2,3,4,...

supervised = to_supervised(scaled_data,lag=timeSteps)

features = scaled_data.shape[1]
X = supervised[:,:features*timeSteps]
y = supervised[:,features*timeSteps]
training_length = int(supervised.shape[0]*0.6)
x_train = X[:training_length,:]
x_test = X[training_length:,:]
y_train = y[:training_length]
y_test = y[training_length:]

#convert data to fit for lstm
x_train = x_train.reshape(x_train.shape[0], timeSteps, features)
x_test = x_test.reshape(x_test.shape[0], timeSteps, features)

# LSTM MODEL
model = Sequential()
model.add(LSTM(128, input_shape = ( timeSteps,x_train.shape[2]), return_sequences = True)) # 128
model.add(Dropout(0.5))
model.add(LSTM(64)) # 64
model.add(Dropout(0.5)) # through grid search, we can find that the dropout_rate does not impact the here #
model.add(Dense(1))
model.add(Activation('relu'))

# MODEL COMPILING AND TRAINING
model.compile(loss='mean_squared_error', optimizer='adagrad') # adagrad (best)
model.fit(x_train, y_train, epochs=500, batch_size=5, verbose=2)

# PREDICTION
trainPredict = model.predict(x_train)
testPredict = model.predict(x_test)

testScore = math.sqrt(mean_squared_error(y_test, testPredict))
print('Test RMSE: %.5f' % (testScore))


trainPredict = trainPredict.reshape((trainPredict.shape[0],))
testPredict = testPredict.reshape((testPredict.shape[0],))

train_length = X[:training_length,:].shape[0]

pd.Series(trainPredict, index= np.arange(train_length)).plot(label='Train Prediction', legend=True)
pd.Series(y[:training_length], index= np.arange(train_length)).plot(label = 'Train Original', legend = True, lw = 3)

pd.Series(testPredict, index= np.arange(train_length, train_length+ y[training_length:].shape[0])).plot(label='Test Prediction', legend=True)
pd.Series(y[training_length:], index= np.arange(train_length, train_length+ y[training_length:].shape[0])).plot(label = 'Test Original', legend = True, lw = 3)
plt.show()
# Test RMSE: 0.18495 - for lag = 1 (60% for training dataset) #
# 0.1824509 (0.008092757954717405) - mean (std)

# ============================================================ #
# Test RMSE:  0.17561, 0.16694, 0.16898, 0.17562, 0.17749, 0.17892 - for lag = 1 (60% for training dataset) - using the features from deep portfolio #
# optimizer: adagrad #
# 0.1739267 (0.007384290316030542) - mean (std)









