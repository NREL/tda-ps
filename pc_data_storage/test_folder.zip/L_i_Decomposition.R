

rm(list = ls())
#setwd("C:/Users/Owner/OneDrive/Desktop/NREL")
setwd("C:/Users/doforib/Desktop/test_folder")


library(rio)

daata = import("result-1.tsv", format = "csv")
data1   = read.csv("result-1.csv")[-2]
data2   = read.csv("result-2.csv")[-2]
dataUnq = read.csv("df_unique_less_than_95_first_5000.csv")[-c(1,3)]


data1_L   = data1[which(colnames(data1)=="L_1"):which(colnames(data1)=="L_118")] 
data2_L   = data2[which(colnames(data2)=="L_1"):which(colnames(data2)=="L_118")] 
dataUnq_L = dataUnq[which(colnames(dataUnq)=="L_1"):which(colnames(dataUnq)=="L_118")] 


#=== Example 1 ===#

LMAX_parts = function(trial){
  
  fifo = trial
  
  t = 1
  LS_max = apply(fifo, 1, sum)[-c(1,nrow(fifo))]
  
  L_DS =  L_S = L_G = L_CAS = matrix(NA, ncol = ncol(fifo), nrow = (nrow(fifo) - 2))
  
  for(i in 1:(nrow(fifo) - 2)){
    
    t = t + 1
    
    aa = fifo[t,]
    bb = fifo[(t+1),]
    
    
    for(j in 1:length(aa)){
      
      if(aa[j] == 0 & bb[j] == 0){
        
        L_DS[i,j]  = 0
        L_S[i,j] = 0
        L_CAS[i,j] = 0
        L_G[i,j] = 0
        
      }else if(aa[j] == 0 & bb[j] > 0){
        L_S[i,j] = as.numeric(bb[j])
        L_DS[i,j] = 0
        L_G[i,j] = as.numeric(bb[j])
        L_CAS[i,j] = 0
        
      }else if(aa[j] >0 & bb[j] == 0){
        
        L_DS[i,j]  = as.numeric(aa[j])
        L_CAS[i,j] = 0
        L_G[i,j] = 0
        L_S[i,j] = as.numeric(bb[j])
        
      }else if(aa[j] >0 & bb[j] > 0 ){
        
        if(aa[j] == bb[j]){
          L_DS[i,j] = 0
          L_S[i,j]  = as.numeric(bb[j])
          L_G[i,j]  = 0
          L_CAS[i,j] = 0
          
        }else if(aa[j] < bb[j]){
          L_DS[i,j]  = 0
          L_CAS[i,j] = 0
          L_G[i,j] = as.numeric(bb[j]) - as.numeric(aa[j])
          L_S[i,j] = as.numeric(bb[j])
          
        }else if (aa[j]> bb[j]){
          L_DS[i,j] = 0
          L_CAS[i,j] = as.numeric(aa[j]) - as.numeric(bb[j])
          L_G[i,j] = 0
          L_S[i,j] = as.numeric(bb[j])
        }
        
        
      }
      
      
    }
    
    
    
  }
  
  
  L_S = as.data.frame(L_S)
  L_S$tot = apply(L_S, 1, sum)
  
  L_DS = as.data.frame(L_DS)
  L_DS$tot = apply(L_DS, 1, sum)
  
  L_G = as.data.frame(L_G)
  L_G$tot = apply(L_G, 1, sum)
  
  L_CAS = as.data.frame(L_CAS)
  L_CAS$tot = apply(L_CAS, 1, sum)
  
  
  nmn = cbind(L_S$tot, L_DS$tot, L_CAS$tot, L_G$tot,LS_max)
  mopo = cbind(L_S$tot, L_DS$tot, L_CAS$tot, L_G$tot)
  dmopo = mopo[,1] + mopo[,2] + mopo[,3] - mopo[,4]
  
  resultsN = data.frame(nmn, dmopo)
  colnames(resultsN) = c("L_SERV", "L_DSHD", "L_CAS", "L_GAIN", "LMAX", "CHK_LMAX")
  return(resultsN)
  
}


aa_1 = c(5,0,0,2,2,2,2,0)
aa0 = c(7,7,7,7,7,7,7,7)
aa1 = c(9,4,4,6,8,0,0,0)
aa2 = c(10,10,10,0,0,0,0,0)
aa3 = c(2,2,1,2,2,2,0,0)
aa4 = c(8,8,8,8,0,0,0,0)
aa5 = c(10,10,0,0,0,0,0,0)
aa6 = c(10,9,8,6,8,8,9,9)

aa_mat = as.data.frame(cbind(aa_1,aa0,aa1,aa2,aa3,aa4,aa5,aa6))
colnames(aa_mat) = c("L_1", "L_2", "L_3", "L_4", "L_5", "L_6", "L_7", "L_8")

ssfpad = LMAX_parts(aa_mat)
rownames(ssfpad) = c("s_1", "s_2", "s_3", "s_4", "s_5", "s_6")

ssfpad


#=== Example 2 ===#

bb_1 = c(5,5,7,9,10)
bb0 = c(3,5,7,9,10)
bb1 = c(3,5,7,9,0)
bb2 = c(4,5,7,0,0)
bb3 = c(4,4,7,0,0)
bb4 = c(3,4,5,0,0)
bb5 = c(0,5,7,0,0)

bb_mat = as.data.frame(rbind(bb_1,bb0,bb1,bb2,bb3,bb4,bb5))
colnames(bb_mat) = c("L_1", "L_2", "L_3", "L_4", "L_5")


ddsfpad = LMAX_parts(bb_mat)
rownames(ddsfpad) = c("s_1", "s_2", "s_3", "s_4", "s_5")

ddsfpad



#=== Example 3 ===#


cc_1 = c(5,0,2,1,0,2,2,0)
cc0 = c(7,7,7,7,7,7,7,7)
cc1 = c(9,4,4,6,8,0,0,0)
cc2 = c(10,10,10,0,0,0,0,0)
cc3 = c(2,2,1,2,2,2,0,0)
cc4 = c(8,8,8,8,0,0,0,0)
cc5 = c(10,10,0,0,0,0,0,0)
cc6 = c(10,9,8,6,8,8,9,9)

cc_mat = as.data.frame(cbind(cc_1,cc0,cc1,cc2,cc3,cc4,cc5,cc6))
colnames(cc_mat) = c("L_1", "L_2", "L_3", "L_4", "L_5", "L_6", "L_7", "L_8")

llfpad = LMAX_parts(cc_mat)
rownames(llfpad) = c("s_1", "s_2", "s_3", "s_4", "s_5", "s_6")

llfpad


#=== Example 4 ===#

bb = data1_L[1:10,1:10]


dob = data1_L[1:100,1:99]
res1_pad = LMAX_parts(dob)


op = par(mfrow = c(2,3))

plot(res1_pad$LMAX, type = "l", col = "red", ylab = "Load_Sum")
plot(res1_pad$L_SERV, type = "l", col = "blue", ylab = "Load_served")
plot(res1_pad$L_DSHD, type = "l", col = "orange", ylab = "Load_Directly_Shed")
plot(res1_pad$L_CAS, type = "l", col = "green", ylab = "Load_due_2_Cascade")
plot(res1_pad$L_GAIN, type = "l", col = "black", ylab = "Load_gained(increase)")


plot(res1_pad$LMAX, type = "l", col = "red", ylim =  c(-2,50))
lines(res1_pad$L_SERV, type = "l", col = "blue", ylab = "Load_served")
lines(res1_pad$L_DSHD, type = "l", col = "orange", ylab = "Load_Directly_Shed")
lines(res1_pad$L_CAS, type = "l", col = "green", ylab = "Load_due_2_Cascade")
lines(res1_pad$L_GAIN, type = "l", col = "black", ylab = "Load_gained(increase)")

par(op)


################################################################################################################################################



res2_pad = LMAX_parts(data1_L)
res2_pad = data.frame(res2_pad,rep(1, nrow(res2_pad)))


op = par(mfrow = c(2,3))

plot(res2_pad$LMAX, type = "l", col = "red", ylab = "Load_Sum")
plot(res2_pad$L_SERV, type = "l", col = "blue", ylab = "Load_served")
plot(res2_pad$L_DSHD, type = "l", col = "orange", ylab = "Load_Directly_Shed")
plot(res2_pad$L_CAS, type = "l", col = "green", ylab = "Load_due_2_Cascade")
plot(res2_pad$L_GAIN, type = "l", col = "black", ylab = "Load_gained(increase)")


plot(res2_pad$LMAX, type = "l", col = "red", ylim =  c(-2,50))
lines(res2_pad$L_SERV, type = "l", col = "blue", ylab = "Load_served")
lines(res2_pad$L_DSHD, type = "l", col = "orange", ylab = "Load_Directly_Shed")
lines(res2_pad$L_CAS, type = "l", col = "green", ylab = "Load_due_2_Cascade")
lines(res2_pad$L_GAIN, type = "l", col = "black", ylab = "Load_gained(increase)")

par(op)



