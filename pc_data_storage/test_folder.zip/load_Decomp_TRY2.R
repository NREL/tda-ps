

rm(list = ls())

library(rio)


setwd("C:/Users/Owner/Box/test_folder")

i = 1

daata = import(paste0("result-",i,".tsv"), format = "csv")


daata_B   = daata[,c(3:120)] 
daata_L   = daata[,c(601:699)] 

#############################################################################################################

# Bus Info #
Bus_Info = ifelse(daata_B == "FALSE",1,0)
#bus_char = as.numeric(Bus_Info)
sec1 = Bus_Info

# Load Info #
Load_Info  = matrix(0, ncol = ncol(Bus_Info), nrow = nrow(Bus_Info))
Load_Info = as.data.frame(Load_Info)
colnames(Load_Info) = c(paste0("L_",seq(1:ncol(Bus_Info))))

Load_Info[,colnames(daata_L)] = daata_L
Load_Info = as.data.frame(Load_Info)
sec2 = Load_Info

# Load Max #


sec3 = Load_Info[1,]

LMAX_Mat = rbind(sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3)
LMAX_Mat = as.matrix(LMAX_Mat)

# Load Directly shed #

LDSHD = ifelse(sec1 == 1, LMAX_Mat, 0)
colnames(LDSHD) = colnames(LMAX_Mat)

# Load Cascd #

LCAS = data.frame(matrix(0,nrow = 120,ncol = 118))
colnames(LCAS) = colnames(LDSHD)

for(i in 1:120){
  
  LCAS[i,] = sec3 - sec2[i,] - LDSHD[i,]
    
    
}

rowSums(LMAX_Mat)

rowSums(LDSHD) + rowSums(LCAS) + rowSums(sec2)


par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)


plot(rowSums(LMAX_Mat), pch = 10, col = "red", ylim = c(-10,45), ylab = "load component", xlab = "# of nodes removed")
lines(rowSums(sec2), col = "blue",pch = 4, type = "b")
lines(rowSums(LDSHD), col = "green",pch = 1, type = "b")
lines(rowSums(LCAS),  col = "orange",pch = 19,type = "b")


legend("topright", bty = "n",inset=c(-0.26,0),
       c(expression(paste(Sigma,"  ","LMAX")), expression(paste(Sigma,"  ","LSVD")), expression(paste(Sigma,"  ","LDSHD")), expression(paste(Sigma,"  ","LCAS"))),
       cex = 0.95, pch = c(10,7,1,19),col=c("red", "blue", "green", "orange")) 


#=== Deltas/Proportions ===#

DLMAX = rowSums(LMAX_Mat)/rowSums(LMAX_Mat)[1]
DLSVD = rowSums(sec2)/rowSums(LMAX_Mat)[1]
DLDSHD = rowSums(LDSHD)/rowSums(LMAX_Mat)[1]
DLCAS = rowSums(LCAS)/rowSums(LMAX_Mat)[1]



par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)


plot(DLMAX, pch = 10, col = "red", ylim = c(-0.2,1), ylab = "load component proportion", xlab = "# of nodes removed")
lines(DLSVD, col = "blue",pch = 4, type = "b")
lines(DLDSHD, col = "green",pch = 1, type = "b")
lines(DLCAS,  col = "orange",pch = 19,type = "b")




legend("topright", bty = "n",inset=c(-0.26,0),
       c(expression(paste(Delta,"  ","LMAX")), expression(paste(Delta,"  ","LSVD")), expression(paste(Delta,"  ","LDSHD")), expression(paste(Delta,"  ","LCAS"))),
       cex = 0.95, pch = c(10,7,1,19),col=c("red", "blue", "green", "orange")) 







