


rm(list = ls())



#################################################################################################################################################

setwd("C:/Users/doforib/Desktop/test_folder/randomforest")


library(randomForest)
library(glmnet)
library(gbm)



#################################################################################################################################################

set.seed(70438)

dataX    = read.csv("new_features.csv",header = T)
LS       = read.csv("fraction_load_served.csv")[,-1]
datacomb = cbind(dataX, LS)[,-115]
#pairs(datacomb[c(1:10),c(110:122)])


train = c(1,sample(2:nrow(datacomb), 3500))
test  = (-train)

data.train  = datacomb[train,]
data.trainY = data.train[,"LS"]

data.test  = datacomb[test,]
data.testY = data.test[,"LS"]


x.mat = model.matrix(LS~., datacomb)[,-1]
y_val = datacomb$LS



bg1 = randomForest(LS~ .,data = datacomb, subset = train, importance = T)
rf2 = randomForest(LS~ .,data = datacomb, subset = train, importance = T, mtry = 50)

pred_bg1 = predict(bg1, newdata = data.test[,-121])
pred_rf1 = predict(rf2, newdata = data.test[,-121])

Bag_MSE  = mean((pred_bg1 - data.testY)^2)
Bag_MAE  = mean(abs(pred_bg1 - data.testY))
Bag_MAPE = mean(abs((pred_bg1 - data.testY)/data.testY))


RF_MSE   = mean((pred_rf1 - data.testY)^2)
RF_MAE   = mean(abs(pred_rf1 - data.testY))
RF_MAPE  = mean(abs((pred_rf1 - data.testY)/data.testY))

#importance(rf2); varImpPlot(rf2,60)


bbo = row.names(importance(rf2))[order((importance(rf2))[,1], decreasing = T)]
x_vars = bbo[1:60]



#################################################################################################################################################

#=== Modeling ===#

#=== RIDGE REG. ===#

rdg_1      = cv.glmnet(x.mat[train,], y_val[train], alpha = 0)
bestlam_R  = rdg_1$lambda.min
pred_rdg   = predict(rdg_1, s = bestlam_R, newx = x.mat[test,]) 

mse_rdg    = mean((pred_rdg - y_val[test])^2)
mae_rdg    = mean(abs(pred_rdg - y_val[test]))
mape_rdg   = mean(abs((pred_rdg - y_val[test])/y_val[test]))


#=== LASSO ===#
las_1      = cv.glmnet(x.mat[train,], y_val[train], alpha = 1)
bestlam_L  = las_1$lambda.min
pred_las   = predict(las_1, s = bestlam_L, newx = x.mat[test,]) 

mse_las    = mean((pred_las - y_val[test])^2)
mae_las    = mean(abs(pred_las - y_val[test]))
mape_las   = mean(abs((pred_las - y_val[test])/y_val[test]))



#=== Boosting ===#
gbm_1 = gbm(LS~., data = data.train, distribution = "gaussian", n.trees = 1000, interaction.depth = 4, shrinkage = 0.2, verbose = F)
gbm_2 = gbm(LS~., data = data.train, distribution = "gaussian", n.trees = 5000, interaction.depth = 4, shrinkage = 0.2, verbose = F)
gbm_3 = gbm(LS~., data = data.train, distribution = "gaussian", n.trees = 1000, interaction.depth = 4, shrinkage = 0.8, verbose = F)


pred_gbm1 = predict(gbm_1, newdata = data.test, n.trees = 1000)
mse_gbm1 = mean((pred_gbm1 - data.testY)^2)

pred_gbm2 = predict(gbm_2, newdata = data.test, n.trees = 5000)
mse_gbm2 = mean((pred_gbm2 - data.testY)^2)

pred_gbm3 = predict(gbm_3, newdata = data.test, n.trees = 1000)
mse_gbm3 = mean((pred_gbm3 - data.testY)^2)
mae_gbm3  = mean(abs(pred_gbm3 - data.testY))
mape_gbm3 = mean(abs((pred_gbm3 - data.testY)/data.testY))


######################################################################################################################################################

#=== Modeling ===#

glm_2    = glmnet(x = as.matrix(data.train[x_vars]), y = data.train[,121], family = "mgaussian")
pred_glm = predict.glmnet(glm_2, as.matrix(data.test[x_vars]), type = "response")

mse_glm  = mean((pred_glm - data.testY)^2)
mae_glm  = mean(abs(pred_glm - data.testY))
mape_glm = mean(abs((pred_glm - data.testY)/data.testY))




#=== Stepwise regression ===#



###########################################################################################################################################################

###########################
#=== MSE ; MAE N MAPE ===#
###########################

# 1. RF N BAG

Bag_MSE  ;  Bag_MAE ;  Bag_MAPE

RF_MSE ;  RF_MAE  ;  RF_MAPE  



# 2. RDG
mse_rdg    ;  mae_rdg   ;  mape_rdg   



# 3. LAS
mse_las  ;  mae_las  ;  mape_las  


#4. GBM 
mse_gbm3; mae_gbm3; mape_gbm3



#5. GLM

mse_glm  ;  mae_glm  ;  mape_glm 


###############
#=== PLOTS ===#
###############



