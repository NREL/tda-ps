
##############################################################################################################################################


rm(list = ls())

start.time = Sys.time()


#setwd("C:/Users/Owner/OneDrive/Desktop/NREL")
setwd("C:/Users/doforib/Desktop/test_folder")

##############################################################################################################################################

dataUnq = read.csv("df_unique_less_than_95_first_5000.csv")[-c(1,3)]
dataUnq_L = dataUnq[which(colnames(dataUnq)=="L_1"):which(colnames(dataUnq)=="L_118")] 
##############################################################################################################################################


###################
#=== FUNCTION ====#
###################


LMAX_parts = function(trial){
  
  fifo = trial
  
  t = 1
  LS_max = apply(fifo, 1, sum)[-c(1,nrow(fifo))]
  
  L_DS =  L_S = L_G = L_CAS = matrix(NA, ncol = ncol(fifo), nrow = (nrow(fifo) - 2))
  
  for(i in 1:(nrow(fifo) - 2)){
    
    t = t + 1
    
    aa = fifo[t,]
    bb = fifo[(t+1),]
    
    
    for(j in 1:length(aa)){
      
      if(aa[j] == 0 & bb[j] == 0){
        
        L_DS[i,j]  = 0
        L_S[i,j] = 0
        L_CAS[i,j] = 0
        L_G[i,j] = 0
        
      }else if(aa[j] == 0 & bb[j] > 0){
        L_S[i,j] = as.numeric(bb[j])
        L_DS[i,j] = 0
        L_G[i,j] = as.numeric(bb[j])
        L_CAS[i,j] = 0
        
      }else if(aa[j] >0 & bb[j] == 0){
        
        L_DS[i,j]  = as.numeric(aa[j])
        L_CAS[i,j] = 0
        L_G[i,j] = 0
        L_S[i,j] = as.numeric(bb[j])
        
      }else if(aa[j] >0 & bb[j] > 0 ){
        
        if(aa[j] == bb[j]){
          L_DS[i,j] = 0
          L_S[i,j]  = as.numeric(bb[j])
          L_G[i,j]  = 0
          L_CAS[i,j] = 0
          
        }else if(aa[j] < bb[j]){
          L_DS[i,j]  = 0
          L_CAS[i,j] = 0
          L_G[i,j] = as.numeric(bb[j]) - as.numeric(aa[j])
          L_S[i,j] = as.numeric(bb[j])
          
        }else if (aa[j]> bb[j]){
          L_DS[i,j] = 0
          L_CAS[i,j] = as.numeric(aa[j]) - as.numeric(bb[j])
          L_G[i,j] = 0
          L_S[i,j] = as.numeric(bb[j])
        }
        
        
      }
      
      
    }
    
    
    
  }
  
  
  L_S = as.data.frame(L_S)
  L_S$tot = apply(L_S, 1, sum)
  
  L_DS = as.data.frame(L_DS)
  L_DS$tot = apply(L_DS, 1, sum)
  
  L_G = as.data.frame(L_G)
  L_G$tot = apply(L_G, 1, sum)
  
  L_CAS = as.data.frame(L_CAS)
  L_CAS$tot = apply(L_CAS, 1, sum)
  
  
  nmn = cbind(L_S$tot, L_DS$tot, L_CAS$tot, L_G$tot,LS_max)
  mopo = cbind(L_S$tot, L_DS$tot, L_CAS$tot, L_G$tot)
  dmopo = mopo[,1] + mopo[,2] + mopo[,3] - mopo[,4]
  
  resultsN = data.frame(nmn, dmopo)
  colnames(resultsN) = c("L_SERV", "L_DSHD", "L_CAS", "L_GAIN", "LMAX", "CHK_LMAX")
  return(resultsN)
  
}



##############################################################################################################################################
# Decomposotion #


res2_pad = LMAX_parts(dataUnq_L)


##############################################################################################################################################




op = par(mfrow = c(2,3))

plot(res2_pad$LMAX, type = "l", col = "red", ylab = "Load_Sum")
plot(res2_pad$L_SERV, type = "l", col = "blue", ylab = "Load_served")
plot(res2_pad$L_DSHD, type = "l", col = "orange", ylab = "Load_Directly_Shed")
plot(res2_pad$L_CAS, type = "l", col = "green", ylab = "Load_due_2_Cascade")
plot(res2_pad$L_GAIN, type = "l", col = "black", ylab = "Load_gained(increase)")


plot(res2_pad$LMAX, type = "l", col = "red", ylim =  c(-2,50))
lines(res2_pad$L_SERV, type = "l", col = "blue", ylab = "Load_served")
lines(res2_pad$L_DSHD, type = "l", col = "orange", ylab = "Load_Directly_Shed")
lines(res2_pad$L_CAS, type = "l", col = "green", ylab = "Load_due_2_Cascade")
lines(res2_pad$L_GAIN, type = "l", col = "black", ylab = "Load_gained(increase)")

par(op)




##############################################################################################################################################



end.time = Sys.time()
time.taken = end.time - start.time



##############################################################################################################################################
