

rm(list = ls())


##############################################################################################################################################

############
# Plotting #
############



# Overlaying lines #

setwd("C:/Users/doforib/Desktop/test_folder/study002/results")

#----------------------------#
#=== All plots one-by-one ===#
#----------------------------#


par(mfrow = c(1,1))

################
# Single plots #
################


#par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)

par(mar = c(5, 4, 4, 2) + 0.1)



i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLMAX, type = "b", col = "red", ylab = expression(paste(Sigma,"  ","LMAX")), 
     ylim = c(0,45),xlab = "sequence of nodes removed",lty = 1, pch = 10, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLSVD, type = "l", col = "blue", ylab = expression(paste(Sigma,"  ","LSVD")), 
     ylim = c(0,45),xlab = "sequence of nodes removed", lty = 2, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLSVD, type = "l", col = "blue",lty=2)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLDSHD, type = "l", col = "orange", ylab = expression(paste(Sigma,"  ","LDSHD")), 
     ylim = c(0,45),xlab = "sequence of nodes removed",lty=3, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLDSHD, type = "l", col = "orange",lty=3)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLCAS, type = "l", col = "green", ylab = expression(paste(Sigma,"  ","LCAS")), 
     ylim = c(-10,20),xlab = "sequence of nodes removed",lty=4, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLCAS, type = "l", col = "green",lty=4)
  
}


###############
# Joint plots #
###############



par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)

i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLMAX, type = "b", col = "red", ylim =  c(-10,45), ylab = "Load value",
     xlab = "sequence of nodes removed",pch =10,lty =  1, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$SLSVD, type = "l", col = "blue",lty = 2)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLSVD, type = "l", col = "blue",lty = 2)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$SLDSHD, type = "l", col = "orange",lty = 3)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLDSHD, type = "l", col = "orange",lty = 3)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$SLCAS, type = "l", col = "green",lty = 4)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLCAS, type = "l", col = "green",lty = 4)
  
}


legend("topright", bty = "n",inset=c(-0.39,0),
       c(expression(paste(Sigma,"  ","LMAX")), expression(paste(Sigma,"  ","LSVD")), expression(paste(Sigma,"  ","LDSHD")), expression(paste(Sigma,"  ","LCAS"))),
       cex = 0.8, pch = c(10,NA,NA,NA),col=c("red", "blue", "orange", "green"),lty = c(1,2,3,4)) 



#==============================================================================================================================#
#------------------------------------------------------------------------------------------------------------------------------#
#==============================================================================================================================#

#-----------------------------#
#=== All plots on one plot ===#
#-----------------------------#

op = par(mfrow = c(2,2))

################
# Single plots #
################


#par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)
par(mar = c(5, 4, 4, 2) + 0.1)

i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLMAX, type = "b", col = "red", ylab = expression(paste(Sigma,"  ","LMAX")), 
     ylim = c(0,45),xlab = "sequence of nodes removed",lty = 1,pch =10, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)         


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLSVD, type = "l", col = "blue", ylab = expression(paste(Sigma,"  ","LSVD")),
     ylim = c(0,45),xlab = "sequence of nodes removed",lty = 2, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLSVD, type = "l", col = "blue",lty= 2)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLDSHD, type = "l", col = "orange", ylab = expression(paste(Sigma,"  ","LDSHD")), 
     ylim = c(0,45),xlab = "sequence of nodes removed",lty = 3, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLDSHD, type = "l", col = "orange",lty = 3)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLCAS, type = "l", col = "green", ylab = expression(paste(Sigma,"  ","LCAS")), 
     ylim = c(-10,20),xlab = "sequence of nodes removed",lty = 4, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLCAS, type = "l", col = "green",lty = 4)
  
}


par(mfrow = c(1,1))


########################################################################################################################


#########################
# ALL LOAD EXCEPT LDSHD #
#########################

par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$SLMAX, type = "b", col = "red", ylim =  c(-10,45), ylab = "Load value",
     xlab = "sequence of nodes removed",pch = 10,lty = 1, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$SLSVD, type = "l", col = "blue",lty = 2)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLSVD, type = "l", col = "blue",lty = 2)
  
}

i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$SLCAS, type = "l", col = "green", lty = 4)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$SLCAS, type = "l", col = "green",lty = 4)
  
}

legend("topright", bty = "n",inset=c(-0.36,0),
       c(expression(paste(Sigma,"  ","LMAX")), expression(paste(Sigma,"  ","LSVD")), expression(paste(Sigma,"  ","LCAS"))),
       cex = 0.8, pch = c(10,NA,NA),col=c("red", "blue", "green"),lty = c(1,2,4)) 






