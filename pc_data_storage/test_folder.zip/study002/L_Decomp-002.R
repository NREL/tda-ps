

rm(list = ls())

start.time = Sys.time()

###################
#=== LIBRARIES ===#
###################

library(rio)

##############################################################################################################################################


###################
#=== FUNCTION ====#
###################


LMAX_Dec2 = function(data_val){
  
  
  daata_B   = data_val[,c(3:120)] 
  daata_L   = data_val[,c(601:699)] 
  
  #############################################################################################################
  
  # Bus Info #
  Bus_Info = ifelse(daata_B == "FALSE",1,0)
  #bus_char = as.numeric(Bus_Info)
  sec1 = Bus_Info
  
  # Load Info #
  Load_Info  = matrix(0, ncol = ncol(Bus_Info), nrow = nrow(Bus_Info))
  Load_Info = as.data.frame(Load_Info)
  colnames(Load_Info) = c(paste0("L_",seq(1:ncol(Bus_Info))))
  
  Load_Info[,colnames(daata_L)] = daata_L
  Load_Info = as.data.frame(Load_Info)
  sec2 = Load_Info
  
  # Load Max #
  
  
  sec3 = Load_Info[1,]
  
  #LMAX_Mat = rbind(sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3,sec3)
  ddop = as.matrix(sec3)
  LMAX_Mat = replicate(nrow(Bus_Info),ddop,simplify = "matrix")
  LMAX_Mat = t(LMAX_Mat)
  
  # Load Directly shed #
  
  LDSHD = ifelse(sec1 == 1, LMAX_Mat, 0)
  colnames(LDSHD) = colnames(LMAX_Mat)
  
  # Load Cascd #
  
  LCAS = data.frame(matrix(0,nrow = nrow(daata_B),ncol = ncol(daata_B)))
  colnames(LCAS) = colnames(LDSHD)
  
  for(i in 1:nrow(daata_B)){
    
    LCAS[i,] = sec3 - sec2[i,] - LDSHD[i,]
    
    
  }
  
  #rowSums(LMAX_Mat)
  
  #rowSums(LDSHD) + rowSums(LCAS) + rowSums(sec2)
  
  
  
  #=== Sum of loads ===#
  
  SLMAX  = rowSums(LMAX_Mat)
  SLSVD  = rowSums(sec2)
  SLDSHD = rowSums(LDSHD)
  SLCAS  = rowSums(LCAS)
  
  
  for(i in 1:length(SLCAS)){
    
    if(SLCAS[i]<0){
      SLCAS[i] = 0
    }
  }
  
  
  #=== Deltas/Proportions ===#
  
  DLMAX  = SLMAX/SLMAX[1]
  DLSVD  = SLSVD/SLMAX[1]
  DLDSHD = SLDSHD/SLMAX[1]
  DLCAS  = SLCAS/SLMAX[1]
  
  resultsN = data.frame(SLMAX,SLSVD,SLDSHD,SLCAS,DLMAX,DLSVD,DLDSHD,DLCAS)
  
  return(resultsN)
  
  
}




############################################################################################################################3

# Decomposotion #

for(i in 1:100){
  
  
  setwd("C:/Users/doforib/Desktop/test_folder/study002/dataset")
  
  
  daata = import(paste0("result-",i,".tsv"), format = "csv")
  
  res2_pad = LMAX_Dec2(daata)
  
  
  setwd("C:/Users/doforib/Desktop/test_folder/study002/results")
  
  
  write.csv(res2_pad, paste0("L_Decomp-",i,".csv"))
  
  
}




##############################################################################################################################################


end.time = Sys.time()

time.taken = end.time - start.time




############################################################################################################################3
# 
# #=== Sum of Loads ===#
# 
# SLMAX = rowSums(LMAX_Mat)
# SLSVD = rowSums(sec2)
# SLDSHD = rowSums(LDSHD)
# SLCAS = rowSums(LCAS)
# 
# 
# 
# #=== Deltas/Proportions ===#
# 
# DLMAX = rowSums(LMAX_Mat)/rowSums(LMAX_Mat)[1]
# DLSVD = rowSums(sec2)/rowSums(LMAX_Mat)[1]
# DLDSHD = rowSums(LDSHD)/rowSums(LMAX_Mat)[1]
# DLCAS = rowSums(LCAS)/rowSums(LMAX_Mat)[1]
# 
# 
# ############################################################################################################################3
# 
# par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)
# 
# plot(rowSums(LMAX_Mat), pch = 10, col = "red", ylim = c(-10,45), ylab = "load component", xlab = "# of nodes removed", main = "result-1(study002)")
# lines(rowSums(sec2), col = "blue",pch = 4, type = "b")
# lines(rowSums(LDSHD), col = "green",pch = 1, type = "b")
# lines(rowSums(LCAS),  col = "orange",pch = 19,type = "b")
# 
# 
# legend("topright", bty = "n",inset=c(-0.26,0),
#        c(expression(paste(Sigma,"  ","LMAX")), expression(paste(Sigma,"  ","LSVD")), expression(paste(Sigma,"  ","LDSHD")), expression(paste(Sigma,"  ","LCAS"))),
#        cex = 0.95, pch = c(10,7,1,19),col=c("red", "blue", "green", "orange")) 
# 
# 
# ###########################################################################################################################3
# 
# par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)
# 
# 
# plot(DLMAX, pch = 10, col = "red", ylim = c(-0.2,1), ylab = "load component proportion", xlab = "# of nodes removed",main = "result-1(study002)")
# lines(DLSVD, col = "blue",pch = 4, type = "b")
# lines(DLDSHD, col = "green",pch = 1, type = "b")
# lines(DLCAS,  col = "orange",pch = 19,type = "b")
# 
# 
# 
# 
# legend("topright", bty = "n",inset=c(-0.26,0),
#        c(expression(paste(Delta,"  ","LMAX")), expression(paste(Delta,"  ","LSVD")), expression(paste(Delta,"  ","LDSHD")), expression(paste(Delta,"  ","LCAS"))),
#        cex = 0.95, pch = c(10,7,1,19),col=c("red", "blue", "green", "orange")) 
# 
# 
# ############################################################################################################################3
# 
# 
# 
# 
# 
# 
