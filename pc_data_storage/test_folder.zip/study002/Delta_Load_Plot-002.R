


rm(list = ls())


##############################################################################################################################################

############
# Plotting #
############



# Overlaying lines #

setwd("C:/Users/Owner/Box/test_folder/study002/results")

#----------------------------#
#=== All plots one-by-one ===#
#----------------------------#


par(mfrow = c(1,1))

################
# Single plots #
################


#par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)

par(mar = c(5, 4, 4, 2) + 0.1)



i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLMAX, type = "b", col = "red", ylab = expression(paste(Delta,"  ","LMAX")), 
     ylim = c(0,1),xlab = "sequence of nodes removed",lty = 1, pch = 10, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)         


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLSVD, type = "l", col = "blue", ylab = expression(paste(Delta,"  ","LSVD")), 
     ylim = c(0,1),xlab = "sequence of nodes removed", lty = 2, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLSVD, type = "l", col = "blue",lty=2)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLDSHD, type = "l", col = "orange", ylab = expression(paste(Delta,"  ","LDSHD")), 
     ylim = c(0,1),xlab = "sequence of nodes removed",lty=3, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLDSHD, type = "l", col = "orange",lty=3)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLCAS, type = "l", col = "green", ylab = expression(paste(Delta,"  ","LCAS")), 
     ylim = c(-0.2,1),xlab = "sequence of nodes removed",lty=4, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLCAS, type = "l", col = "green",lty=4)
  
}


###############
# Joint plots #
###############



par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)

i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLMAX, type = "b", col = "red", ylim =  c(-0.2,1), ylab = "Load value",
     xlab = "sequence of nodes removed",pch =10,lty =  1, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$DLSVD, type = "l", col = "blue",lty = 2)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLSVD, type = "l", col = "blue",lty = 2)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$DLDSHD, type = "l", col = "orange",lty = 3)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLDSHD, type = "l", col = "orange",lty = 3)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$DLCAS, type = "l", col = "green",lty = 4)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLCAS, type = "l", col = "green",lty = 4)
  
}


legend("topright", bty = "n",inset=c(-0.39,0),
       c(expression(paste(Delta,"  ","LMAX")), expression(paste(Delta,"  ","LSVD")), expression(paste(Delta,"  ","LDSHD")), expression(paste(Delta,"  ","LCAS"))),
       cex = 0.8, pch = c(10,NA,NA,NA),col=c("red", "blue", "orange", "green"),lty = c(1,2,3,4)) 



#==============================================================================================================================#
#------------------------------------------------------------------------------------------------------------------------------#
#==============================================================================================================================#

#-----------------------------#
#=== All plots on one plot ===#
#-----------------------------#

op = par(mfrow = c(2,2))

################
# Single plots #
################


#par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)
par(mar = c(5, 4, 4, 2) + 0.1)

i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLMAX, type = "b", col = "red", ylab = expression(paste(Delta,"  ","LMAX")), 
     ylim = c(0,1),xlab = "sequence of nodes removed",lty = 1,pch =10, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)         


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLSVD, type = "l", col = "blue", ylab = expression(paste(Delta,"  ","LSVD")), 
     ylim = c(0,1),xlab = "sequence of nodes removed",lty = 2, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLSVD, type = "l", col = "blue",lty= 2)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLDSHD, type = "l", col = "orange", ylab = expression(paste(Delta,"  ","LDSHD")), 
     ylim = c(0,1),xlab = "sequence of nodes removed",lty = 3, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLDSHD, type = "l", col = "orange",lty = 3)
  
}


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLCAS, type = "l", col = "green", ylab = expression(paste(Delta,"  ","LCAS")), 
     ylim = c(-0.2,1),xlab = "sequence of nodes removed",lty = 4, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLCAS, type = "l", col = "green",lty = 4)
  
}


par(mfrow = c(1,1))


########################################################################################################################


#########################
# ALL LOAD EXCEPT LDSHD #
#########################

par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

plot(res2_pad$DLMAX, type = "b", col = "red", ylim =  c(-0.2,1), ylab = "Load value",
     xlab = "sequence of nodes removed",pch = 10,lty = 1, xaxt = "n")         
axis(1, at=0:119, labels=-1:118)


i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$DLSVD, type = "l", col = "blue",lty = 2)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLSVD, type = "l", col = "blue",lty = 2)
  
}

i = 1
res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))

lines(res2_pad$DLCAS, type = "l", col = "green", lty = 4)

for(i in 2:100){
  
  res2_pad = read.csv(paste0("L_Decomp-",i,".csv"))
  
  lines(res2_pad$DLCAS, type = "l", col = "green",lty = 4)
  
}

legend("topright", bty = "n",inset=c(-0.36,0),
       c(expression(paste(Delta,"  ","LMAX")), expression(paste(Delta,"  ","LSVD")), expression(paste(Delta,"  ","LCAS"))),
       cex = 0.8, pch = c(10,NA,NA),col=c("red", "blue", "green"),lty = c(1,2,4)) 






