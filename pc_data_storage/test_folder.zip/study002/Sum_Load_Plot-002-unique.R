

rm(list = ls())


##############################################################################################################################################

############
# Plotting #
############



# Overlaying lines #

setwd("C:/Users/doforib/Desktop/test_folder/study002/results")

#----------------------------#
#=== All plots one-by-one ===#
#----------------------------#


res2_pad = read.csv("L_Decomp-unique.csv")


par(mfrow = c(1,1))

################
# Single plots #
################


#par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)

par(mar = c(5, 4, 4, 2) + 0.1)

plot(res2_pad$SLMAX, type = "b", col = "red", ylab = expression(paste(Sigma,"  ","LMAX")), 
     ylim = c(0,45),xlab = "sequence of nodes ",lty = 1, pch = 10, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)


plot(res2_pad$SLSVD, type = "l", col = "blue", ylab = expression(paste(Sigma,"  ","LSVD")), 
     ylim = c(0,45),xlab = "sequence of nodes ", lty = 2, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)


plot(res2_pad$SLDSHD, type = "l", col = "orange", ylab = expression(paste(Sigma,"  ","LDSHD")), 
     ylim = c(0,45),xlab = "sequence of nodes ",lty=3, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)


plot(res2_pad$SLCAS, type = "l", col = "green", ylab = expression(paste(Sigma,"  ","LCAS")), 
     ylim = c(0,36),xlab = "sequence of nodes ",lty=4, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)


###############
# Joint plots #
###############



par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)


plot(res2_pad$SLMAX, type = "b", col = "red", ylim =  c(0,45), ylab = "Load value",
     xlab = "sequence of nodes ",pch =10,lty =  1, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)

lines(res2_pad$SLSVD, type = "l", col = "blue",lty = 2)
lines(res2_pad$SLDSHD, type = "l", col = "orange",lty = 3)
lines(res2_pad$SLCAS, type = "l", col = "green",lty = 4)


legend("topright", bty = "n",inset=c(-0.39,0),
       c(expression(paste(Sigma,"  ","LMAX")), expression(paste(Sigma,"  ","LSVD")), expression(paste(Sigma,"  ","LDSHD")), expression(paste(Sigma,"  ","LCAS"))),
       cex = 0.8, pch = c(10,NA,NA,NA),col=c("red", "blue", "orange", "green"),lty = c(1,2,3,4)) 



#==============================================================================================================================#
#------------------------------------------------------------------------------------------------------------------------------#
#==============================================================================================================================#

#-----------------------------#
#=== All plots on one plot ===#
#-----------------------------#

op = par(mfrow = c(2,2))

################
# Single plots #
################


#par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)
par(mar = c(5, 4, 4, 2) + 0.1)

plot(res2_pad$SLMAX, type = "b", col = "red", ylab = expression(paste(Sigma,"  ","LMAX")), 
     ylim = c(0,45),xlab = "sequence of nodes ",lty = 1,pch =10, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)         



plot(res2_pad$SLSVD, type = "l", col = "blue", ylab = expression(paste(Sigma,"  ","LSVD")),
     ylim = c(0,45),xlab = "sequence of nodes ",lty = 2, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)


plot(res2_pad$SLDSHD, type = "l", col = "orange", ylab = expression(paste(Sigma,"  ","LDSHD")), 
     ylim = c(0,45),xlab = "sequence of nodes ",lty = 3, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)


plot(res2_pad$SLCAS, type = "l", col = "green", ylab = expression(paste(Sigma,"  ","LCAS")), 
     ylim = c(0,36),xlab = "sequence of nodes ",lty = 4, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)


par(mfrow = c(1,1))


########################################################################################################################


#########################
# ALL LOAD EXCEPT LDSHD #
#########################

par(mar=c(5.1, 4.1, 4.1, 12.1), xpd=TRUE)


plot(res2_pad$SLMAX, type = "b", col = "red", ylim =  c(0,45), ylab = "Load value",
     xlab = "sequence of nodes ",pch = 10,lty = 1, xaxt = "n")         
axis(1, at=0:2001, labels=-1:2000)

lines(res2_pad$SLSVD, type = "l", col = "blue",lty = 2)
lines(res2_pad$SLCAS, type = "l", col = "green", lty = 4)

legend("topright", bty = "n",inset=c(-0.36,0),
       c(expression(paste(Sigma,"  ","LMAX")), expression(paste(Sigma,"  ","LSVD")), expression(paste(Sigma,"  ","LCAS"))),
       cex = 0.8, pch = c(10,NA,NA),col=c("red", "blue", "green"),lty = c(1,2,4)) 






