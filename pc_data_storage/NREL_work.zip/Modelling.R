

rm(list = ls())

start.time = Sys.time()


############################################################################################################################

setwd("C:/Users/Owner/OneDrive/Desktop/NREL")


library(rio)

data = import("unique.tsv", format = "csv")


nR_data = sample(1:nrow(data), 5000, replace = F)

data2 = data[nR_data, ]



nR_data2 =  sample(1:nrow(data), 3000, replace = F)

data3 = data[nR_data2, ]





