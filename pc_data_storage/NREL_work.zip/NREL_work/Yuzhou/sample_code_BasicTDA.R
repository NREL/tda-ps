#---------------------------------------------------------------------------


rm(list = ls()) # Remove all the objects we created so far.

setwd("C:/Users/Dorcas/Desktop/TDA and Power grid research/codes/My_Code")

###############################################################################

#==== Libraries ===#
library(Matrix)
library(igraph)
library(TDA)

###################################################################################################

data12        = read.csv("branch.csv")
data_reac     = data12[,c(3,4,6)]
unique_data   = unique(data_reac)

unique_data11 = unique_data

#=================================================================================================#
#=== Edges ===#

unique_data11[,1] = as.character(unique_data11[,1])
unique_data11[,2] = as.character(unique_data11[,2])

gg           = graph.edgelist(as.matrix(unique_data11[,1:2]), directed = F)
E(gg)$weight = as.numeric(unique_data11[,3])
network      = gg

############################################################################################################

# TDA constants #
cap      = 3 # dimension cap
delta    = 0.1
filt_len = 100



############################################################################################################
#=== betti numbers ===#

betti_0 = betti_1 = c()

  
  A1 =  get.adjacency(network, attr = "weight")
  A2 = as.matrix(A1)
  
  A2[A2 == 0] = 999
  diag(A2)    = 0
  
  
  d  = length(V(network))
  print(d); print(length(E(network)))
 
  # writing data into file M.txt
  cat(d, file = 'M.txt', append = F, sep = '\n')
  cat(paste(0, delta, filt_len, cap, sep = ' '), file = 'M.txt', append = T, sep = '\n') 
  cat(A2, file = 'M.txt', append = T) 
  
  system('perseusWin.exe distmat M.txt Moutput')
  
  # read Betti numbers from file Moutput_betti.txt
  
  betti_data  = as.matrix(read.table('Moutput_betti.txt'))
  betti_index = setdiff(0:filt_len, betti_data[,1])
  
  for (k in betti_index) 
    if (k < length(betti_data[ ,1])) 
    {
      betti_data  = rbind(betti_data[1:k, ], betti_data[k,], betti_data[(k+1):length(betti_data[,1]), ])
      betti_index = betti_index + 1
    } else
      betti_data  = rbind(betti_data[1:k,], betti_data[k,])
  
  betti_0 = rbind(betti_0, betti_data[,2])
  betti_1 = rbind(betti_1, betti_data[,3])
  

  
  # read birth and death times for each dimension
  
  # dim=0
  persist_data = as.matrix(read.table('Moutput_0.txt'))
  persist_data[persist_data[,2] == -1, 2] = filt_len + 1
  persist_data = persist_data/(filt_len + 1)
  P = cbind(rep(0, nrow(persist_data)), persist_data)
  
  # dim=1
  if (file.info('Moutput_1.txt')$size>0)
  { 
    persist_data = as.matrix(read.table('Moutput_1.txt', blank.lines.skip = T))
    persist_data[persist_data[,2] == -1, 2] = filt_len + 1
    persist_data = persist_data/(filt_len + 1)
    P = rbind(P, cbind(rep(1, nrow(persist_data)), persist_data))
    
  }
  
  
############################################################################################################
