


rm(list = ls())



setwd("C:/Users/Owner/OneDrive/Documents/NREL/NREL_work")


#######################################################################################################


library(igraph)
library(RCurl)
library(TDA)


source("Resil_func.R")



#######################################################################################################


###################
#=== CONSTANTS ===#
###################

frac = seq(0,0.4, by = 0.1)



#######################################################################################################



case_118_graph = read.csv("graph_118_case.csv",sep = ";", header = TRUE, row.names = 1)
case_118_graph_final_version = case_118_graph[3:dim(case_118_graph)[2],3:dim(case_118_graph)[2]]

# separate bus, load, and thermal #
# include bus_ 's rows #
bus_index = colnames(case_118_graph_final_version) %in% grep('bus', colnames(case_118_graph_final_version), value=TRUE)
bus_part = case_118_graph_final_version[bus_index,bus_index]

# include bus_ 's rows #
bus_index = colnames(case_118_graph_final_version) %in% grep('bus', colnames(case_118_graph_final_version), value=TRUE)
bus_part = case_118_graph_final_version[bus_index,bus_index]
bus_part = as.matrix(bus_part)


# construct ieee 118 case graph structure #
#case_118_network = graph_from_adjacency_matrix(as.matrix(bus_part), mode = "directed")

case_118_network = graph_from_adjacency_matrix(as.matrix(bus_part), mode = "undirected")
V(case_118_network)$name = 1:118

#plot(case_118_network, vertex.size = 5, edge.width  = 0.1, edge.color = "black", edge.arrow.size = 0.1)

plot(case_118_network, vertex.size = 5, edge.width  = 0.1, edge.color = "black", edge.arrow.size = 0.1, vertex.label = NA)


############################################################################################################################################


############################################################
#=================== RESILIENCE METRICS ===================#
############################################################



################
#=== MOTIFS ===#
################


#=== 1. NODE ===#

# Degree #
NodeM_degree = Resilience_Attacks2(attack = "node", graph_type = "unweighted", analysis = "Motifs", type = "degree", case_118_network, frac)
NodeM_degreeMatrix = as.matrix(NodeM_degree)
colnames(NodeM_degreeMatrix) = c("fr", "Tot_M", "M1", "M2", "M3", "M4", "M5", "C_M1", "C_M2", "C_M3", "C_M4", "C_M5")



#=== 2. EDGE ===#

# Edge Betweenness Centrality #
EdgeM_betw = Resilience_Attacks2(attack = "edge", graph_type = "unweighted", analysis = "Motifs", type = "E_betweeness", case_118_network, frac)
EdgeM_betwMatrix = as.matrix(EdgeM_betw)
colnames(EdgeM_betwMatrix) = c("fr", "Tot_M", "M1", "M2", "M3", "M4", "M5", "C_M1", "C_M2", "C_M3", "C_M4", "C_M5")


#############
#=== TDA ===#
#############


# Degree #
NodeTDA_degree = Resilience_Attacks2(attack = "node", graph_type = "weighted", analysis = "TDA", type = "degree", case_118_network, frac)
NodeTDA_degreeMatrix = as.matrix(NodeTDA_degree)
colnames(NodeTDA_degreeMatrix) = c("fr", "Betti0", "Betti1","Wass01")



# E_Betw #
EdgeTDA_betw= Resilience_Attacks2(attack = "edge", graph_type = "weighted", analysis = "TDA", type = "E_betweeness", case_118_network, frac)
EdgeTDA_betwMatrix = as.matrix(EdgeTDA_betw)
colnames(EdgeTDA_betwMatrix) = c("fr", "Betti0", "Betti1","Wass01")



############################################################################################################################################





